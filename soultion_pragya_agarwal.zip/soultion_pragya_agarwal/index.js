
const solution = require('./solution.js');
const data = require('./data.js');
const fs = require('fs');
const finalClicks = solution.removeIpExceedingCount(data.ipArray);
console.log(finalClicks);
fs.writeFile("resultset.json", JSON.stringify(finalClicks), (err) => {
    if (err) throw err;
    console.log('complete');
}
);