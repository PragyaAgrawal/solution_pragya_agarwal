
const solution = require('../solution.js');
const data = require('../data');
const expect = require("chai").expect;
describe("Array of Click", () => {
    describe("IP array clicks", () => {
        it("expensive ip output", () => {
            const output = solution.removeIpExceedingCount(data.ipArray);
            const expectedOutput = [{ "ip": "44.44.44.44", "timestamp": "3/11/2016 02:13:54", "amount": 8.75 },
            { "ip": "11.11.11.11", "timestamp": "3/11/2016 02:13:11", "amount": 7.25 },
            { "ip": "11.11.11.11", "timestamp": "3/11/2016 06:45:01", "amount": 12 },
            { "ip": "44.44.44.44", "timestamp": "3/11/2016 06:32:42", "amount": 5 }, { "ip": "33.33.33.33", "timestamp": "3/11/2016 07:02:54", "amount": 15.75 }, { "ip": "66.66.66.66", "timestamp": "3/11/2016 07:02:54", "amount": 14.25 }, { "ip": "11.11.11.11", "timestamp": "3/11/2016 07:02:54", "amount": 4.5 }, { "ip": "55.55.55.55", "timestamp": "3/11/2016 13:02:40", "amount": 8 }, { "ip": "44.44.44.44", "timestamp": "3/11/2016 13:02:55", "amount": 8 }, { "ip": "55.55.55.55", "timestamp": "3/11/2016 14:03:04", "amount": 5.25 }, { "ip": "55.55.55.55", "timestamp": "3/11/2016 15:12:55", "amount": 6.25 }, { "ip": "55.55.55.55", "timestamp": "3/11/2016 16:22:11", "amount": 8.5 }, { "ip": "55.55.55.55", "timestamp": "3/11/2016 17:18:19", "amount": 11.25 },
            { "ip": "55.55.55.55", "timestamp": "3/11/2016 18:19:20", "amount": 9 }]
            expect(output).to.eql(expectedOutput);

        });
    });
});