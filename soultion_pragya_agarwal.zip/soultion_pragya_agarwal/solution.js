let expensiveIpArr = [];
let arrCount = 0;
let currentDate = '';
let startTimestamp = '';

exports.removeIpExceedingCount = (ipArray) => {
    const ipCountArr = getIpCounts(ipArray);
    for (let indx in ipCountArr) {
        if (ipCountArr[indx] > 10) {
            const uniqueArr = ipArray.filter((obj) => {
                return indx !== obj.ip;
            });
            if (uniqueArr.length) {
                return getIpObj(uniqueArr);
            }
        }
    }
}

const getIpCounts = (arr) => {
    let ipobj = {};

    arr.forEach((val, index) => {
        if (ipobj[val.ip] === undefined) {
            ipobj[val.ip] = 1
        } else {
            ipobj[val.ip] += 1
        }
    });
    return ipobj
}

const getDateMonthYear = (timeStamp, hours) => {
    const dateTimeStamp = new Date(timeStamp);
    const date = dateTimeStamp.getDate();
    const year = dateTimeStamp.getFullYear();
    const month = dateTimeStamp.getMonth();
    return new Date(year, month, date, hours, 0, 0);
}

const liebetween = (initialDate, date, range) => {
    let totalMins = Math.floor(((date - initialDate) / 1000) / 60);
    if (0 < totalMins && range < totalMins) {
        return liebetween(initialDate, date, range + 60)
    } else {
        const inHours = range / 60;
        let getInitialHours = '';
        if (inHours == date.getHours()) {
            return getDateMonthYear(initialDate, inHours);
        } else if (inHours < date.getHours()) {
            return getDateMonthYear(initialDate, date.getHours());
        } else {
            return getDateMonthYear(initialDate, (range - 60) / 60);
        }
    }
}

const getIpObj = (uniqueIpArr) => {
    const ipArrClicks = [...uniqueIpArr];
    //Setting inital time 
    const initialDate = getDateMonthYear(ipArrClicks[0].timestamp, 0);
    //Get current time stamp including mins
    currentDate = new Date(ipArrClicks[0].timestamp);

    const { count, data } = getExpensiveIPs(initialDate, currentDate, ipArrClicks);
    //Get time without mins
    expensiveIpArr = [...data];

    arrCount += count;
    return getIpClickArr(ipArrClicks, arrCount);
}

const getIpClickArr = (ipArrClicks, arrCount) => {
    if (ipArrClicks[arrCount] !== undefined) {
        ipArrClicks.splice(0, arrCount);
        for (let i = 0; i < ipArrClicks.length; i++) {
            const nextDate = new Date(ipArrClicks[i].timestamp);
            const { count, data } = getExpensiveIPs(currentDate, nextDate, ipArrClicks);
            expensiveIpArr = [...expensiveIpArr, ...data];
            arrCount += count;
            return getIpClickArr(ipArrClicks, count);
        }
    } else {
        return expensiveIpArr;
    }
}

const getExpensiveIPs = (initialDate, currentDate, ipArrClicks) => {
    startTimestamp = liebetween(initialDate, currentDate, 60);
    let ipAddreInHour = ipArrClicks.filter((val, index) => {
        let minsDiff = timestampDiffMin(val.timestamp, startTimestamp);
        return minsDiff <= 60 ? val : '';
    })
    return {
        count: ipAddreInHour.length,
        data: getExpensiveClick(ipAddreInHour)
    };
}

const getExpensiveClick = (ipAddress) => {
    const sortedAmt = ipAddress.sort((a, b) => (a.amount < b.amount) ? 1 : ((b.amount < a.amount) ? -1 : 0));
    const expensiveIP = sortedAmt[0].ip;
    let amt = [];
    let expensiveClick = [];
    let ipCounts = getIpCounts(sortedAmt);
    for (let indx in ipCounts) {
        if (ipCounts[indx] === 1
            || (expensiveIP === indx && ipCounts[indx] === 1)
            || (ipCounts[indx] > 1 && expensiveIP !== indx)) {
            amt = sortedAmt.filter((val) => { return val.ip === indx });
            expensiveClick.push(amt[0]);

        } else if (ipCounts[indx] > 1 && expensiveIP === indx) {
            const amtArr = ipAddress.filter((val) => { return val.ip === indx });
            expensiveClick.push(amtArr[0]);
        }
    }
    return expensiveClick;
}

const timestampDiffMin = (dt2, dt1) => {
    let diff = (new Date(dt2).getTime() - new Date(dt1).getTime()) / 1000;
    diff /= (60);
    return Math.abs(Math.round(diff));
}

// removeIpExceedingCount();